/**
 * Common Notification Types — Authentication and subscription delivery controls.
 *
 * @module common/notifications
 */

import type {
  ProtectedResourceMetadata,
  URI,
  Snapshot,
} from './state.js';

/**
 * Reason why authentication is required.
 *
 * @category Protocol Notifications
 * @nonexhaustive
 */
export const enum AuthRequiredReason {
  /** The client has not yet authenticated for the resource */
  Required = 'required',
  /**
   * A previously valid token has expired or been revoked. The client must
   * acquire or renew the credential rather than replaying the challenged token.
   */
  Expired = 'expired',
}

// ─── auth/required ───────────────────────────────────────────────────────────

/**
 * Sent by the server when a protected resource requires (re-)authentication.
 *
 * This notification MAY be associated with any channel — for example, an
 * agent advertised on the root channel, or a per-session resource. The
 * `channel` field identifies the subscription the auth requirement belongs
 * to; the `resource` field carries the complete OAuth protected resource
 * metadata (per RFC 9728).
 *
 * Clients should obtain or renew the credential and push the resulting token
 * via the `authenticate` command. When `reason` is `expired`, clients MUST NOT
 * blindly replay the challenged token.
 *
 * @category Protocol Notifications
 * @method auth/required
 * @direction Server → Client
 * @messageType Notification
 * @version 1
 * @see {@link /specification/authentication | Authentication}
 * @example
 * ```json
 * {
 *   "jsonrpc": "2.0",
 *   "method": "auth/required",
 *   "params": {
 *     "channel": "ahp-root://",
 *     "resource": {
 *       "resource": "https://api.github.com",
 *       "resource_name": "GitHub API",
 *       "authorization_servers": ["https://github.com/login/oauth"]
 *     },
 *     "reason": "expired"
 *   }
 * }
 * ```
 */
export interface AuthRequiredParams {
  /** Channel URI this notification belongs to */
  channel: URI;
  /** Complete RFC 9728 metadata for the protected resource that requires authentication */
  resource: ProtectedResourceMetadata;
  /** Why authentication is required */
  reason?: AuthRequiredReason;
}

/**
 * One fragment of a data message on a windowed subscription.
 *
 * A sender uses fragments when a data message is larger than
 * `maximumFrameBytes`, and to let subscriptions take turns so that one busy
 * subscription does not hold up the whole connection. It serializes the message
 * to JSON text, divides the text into pieces, and sends each piece in order. The
 * receiver joins the `data` strings and parses the result only after it receives
 * the fragment with `final: true`.
 *
 * Fragments MUST NOT be empty and MUST NOT divide a UTF-16 surrogate pair. The
 * channel inside the joined message MUST match `channel`. For each subscription
 * and direction, only one fragmented message can be in progress. Control
 * messages, requests, and responses MUST NOT be sent in fragments.
 *
 * Each fragment counts against the window when it is sent, by the size of the
 * complete `channel/frame` message, including its envelope and escape
 * characters. If the window becomes full partway through a message, the sender
 * waits for credit before it sends the next fragment.
 *
 * @category Protocol Notifications
 * @method channel/frame
 * @stability 1.0
 * @direction Both
 * @messageType Notification
 * @version 1
 * @see {@link /specification/windowed-delivery#fragments | Windowed Delivery: Fragments}
 */
export interface ChannelFrameParams {
  /** The URI of the windowed subscription. */
  channel: URI;
  /**
   * The next piece of the serialized JSON-RPC message.
   * @minLength 1
   */
  data: string;
  /** `true` on the last fragment of the message. Absent or `false` on other fragments. */
  final?: boolean;
}

/**
 * Reports how much data the receiver has released.
 *
 * `consumedBytes` is the total size, in UTF-16 bytes, of the data messages and
 * fragments that the receiver has released on this subscription. It is a total,
 * not an increment, and can be any value up to the amount of data sent; it does
 * not need to match the end of a message or fragment. The size of a message or
 * fragment is the size of its complete JSON-RPC text as received.
 *
 * The receiver decides when to send credit; for example, after it applies an
 * action, after stream data leaves its local buffer, or after it stores a
 * fragment for reassembly. When outstanding data reaches `windowBytes`, the
 * receiver MUST send credit as soon as it is ready to receive more data.
 *
 * A sender ignores a value that is not greater than the previous value. The
 * protocol does not define what happens when the value is greater than the data
 * sent; an implementation can log the error or close the connection.
 *
 * @category Protocol Notifications
 * @method channel/credit
 * @windowExempt
 * @stability 1.0
 * @direction Both
 * @messageType Notification
 * @version 1
 * @see {@link /specification/windowed-delivery#window-and-credit | Windowed Delivery: Window and Credit}
 */
export interface ChannelCreditParams {
  /** The URI of the windowed subscription. */
  channel: URI;
  /**
   * Total UTF-16 bytes of data messages and fragments that the receiver has released.
   * @integer
   * @minimum 0
   * @maximum 9007199254740991
   */
  consumedBytes: number;
}

/**
 * Sends the state of a channel to a windowed subscription.
 *
 * On a windowed subscription, the `subscribe` result does not contain a
 * snapshot. The server sends this notification instead. It MUST be the first
 * data message that the server sends on every windowed subscription, and the
 * first after `snapshot` recovery. If it is sent in fragments, this applies to
 * the joined message. Data messages after it are changes to this state, or new
 * data for the channel. For a channel whose state has no fields,
 * `snapshot.state` is an {@link EmptyState} and `snapshot.fromSeq` is the
 * server's current `serverSeq`.
 *
 * This is a data message that counts against the window. The server can send it
 * in `channel/frame` fragments, and MUST do so if it is larger than
 * `maximumFrameBytes`. `snapshot.resource` MUST be the same as `channel`.
 *
 * The server does not send this notification on ordinary subscriptions.
 *
 * @category Protocol Notifications
 * @method channel/snapshot
 * @stability 1.0
 * @direction Server → Client
 * @messageType Notification
 * @version 1
 * @see {@link /specification/windowed-delivery#initial-data | Windowed Delivery: Initial Data}
 */
export interface ChannelSnapshotParams {
  /** The URI of the windowed subscription. */
  channel: URI;
  /** The channel's state. */
  snapshot: Snapshot;
}
