/**
 * TCP Commands — Creating a private TCP forwarding connection.
 *
 * @module channels-tcp/commands
 */

import type { URI } from '../common/state.js';
import type { BaseParams } from '../common/commands.js';

/**
 * Opens a TCP connection from the host to a destination on the host's network.
 *
 * The client chooses the channel URI. This command does not subscribe: after it
 * succeeds, the client subscribes to the channel with windowed delivery. The
 * host MUST NOT send data for the channel before that subscription, and MUST
 * limit how much destination data it buffers and how long it keeps a
 * connection that is never subscribed to.
 *
 * The client MUST NOT send this command unless `InitializeResult.tcpConnections`
 * is present. If the channel URI is already in use, the host returns
 * `AlreadyExists` and MUST NOT replace the existing connection. If the host
 * cannot open the connection, it returns `TcpConnectionOpenFailed`.
 *
 * @category TCP Commands
 * @method createTcpConnection
 * @direction Client → Server
 * @messageType Request
 * @version 1
 * @stability 1.0
 * @see {@link /specification/tcp-channel | TCP Channel}
 */
export interface CreateTcpConnectionParams extends BaseParams {
  /** The client-chosen URI for the new channel, for example `ahp-tcp:/<uuid>`. */
  channel: URI;
  /** A DNS name or IP address, resolved on the host's network. Not a URL. */
  host: string;
  /**
   * The destination port.
   * @integer
   * @minimum 1
   * @maximum 65535
   */
  port: number;
}
