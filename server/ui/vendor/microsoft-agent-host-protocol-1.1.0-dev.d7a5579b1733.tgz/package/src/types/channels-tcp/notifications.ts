/**
 * TCP Notifications — Data, end-of-stream, and abort messages.
 *
 * @module channels-tcp/notifications
 */

import type { URI } from '../common/state.js';

/**
 * Bytes in the sender's direction: from the client to the destination, or from
 * the destination to the client.
 *
 * The receiver writes the decoded bytes in the order received. The boundaries
 * between `tcp/data` notifications have no meaning. Data is not sent again
 * after the AHP connection is lost.
 *
 * @category TCP Notifications
 * @method tcp/data
 * @direction Both
 * @messageType Notification
 * @version 1
 * @stability 1.0
 * @see {@link /specification/tcp-channel | TCP Channel}
 */
export interface TcpDataParams {
  /** The URI of the TCP channel. */
  channel: URI;
  /**
   * The bytes, as padded RFC 4648 base64 without whitespace.
   * @minLength 1
   */
  data: string;
}

/**
 * Ends the sender's direction after the data that it has already sent, like a
 * TCP FIN. The other direction can continue. The sender MUST NOT send more
 * `tcp/data` after `tcp/eof`.
 *
 * This notification counts against the window, so the sender may have to wait
 * for credit before sending it. A receiver MUST release `tcp/data` as it writes
 * the bytes, without waiting for `tcp/eof`.
 *
 * @category TCP Notifications
 * @method tcp/eof
 * @direction Both
 * @messageType Notification
 * @version 1
 * @stability 1.0
 * @see {@link /specification/tcp-channel | TCP Channel}
 */
export interface TcpEofParams {
  /** The URI of the TCP channel. */
  channel: URI;
}

/**
 * Aborts the connection in both directions, like a TCP RST.
 *
 * The sender discards data that it has not yet sent. The receiver discards data
 * that it has not yet written, and closes its own side of the connection. The
 * host sends `tcp/reset` when the destination connection fails or is reset, or
 * when the client sends invalid data. The client sends it to abort the
 * connection without waiting for buffered data to be written. After `tcp/reset`,
 * neither peer sends more data on the channel.
 *
 * Unlike `tcp/data` and `tcp/eof`, this notification does not count against the
 * window, so it can be sent when the window is full.
 *
 * @category TCP Notifications
 * @method tcp/reset
 * @windowExempt
 * @direction Both
 * @messageType Notification
 * @version 1
 * @stability 1.0
 * @see {@link /specification/tcp-channel | TCP Channel}
 */
export interface TcpResetParams {
  /** The URI of the TCP channel. */
  channel: URI;
}
